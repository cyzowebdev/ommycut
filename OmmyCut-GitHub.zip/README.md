# OmmyCut

OmmyCut turns long videos and livestreams into short, captioned clips. It runs on your own computer: videos, clips, settings and keys stay in the install folder.

Repo: https://github.com/cyzowebdev/ommycut.git

## Install on Windows

1. Download `OmmyCut-Installer.exe` from this repo's Releases (or build it with `installer/build-installer.ps1`).
2. Run it. It downloads this repo, installs a private Python runtime and ffmpeg, creates Desktop/Start menu shortcuts, and starts OmmyCut.

Nothing except the source code is downloaded from GitHub. Your data is never uploaded by the installer.

## Run from source

```bat
python -m pip install -r app/requirements.txt
OmmyCut.cmd
```

The desktop launcher is `python\OmmyCut.exe -m studio.desktop`. The console launcher is `OmmyCut.cmd`.

## Phone access

Open **Phone access** in the app, set a 4–12 digit PIN, then open the shown `http://<pc-ip>:8765/app` address on a phone connected to the same Wi-Fi. The PIN and unlock state are kept outside the replaceable `app` folder.

## What is in this repo

- `app/studio` — FastAPI server, clipping jobs, facecam/tag/render mechanics
- `app/web` — desktop and phone UI, brand assets, caption-style previews
- `OmmyCut.cmd` — console launcher
- `ommycut.ico` — Windows icon
- `installer/install.ps1` — one-click installer source
- `installer/build-installer.ps1` — builds the single-file Windows installer

## Privacy

No analytics, no account required for local use, and no user content is sent to the project repo. Optional AI keys and posting integrations talk only to the services you connect.

Built by Soham Chatterjee.
