"""OmmyCut as a desktop app on Windows: its own window, and no black console window behind it.

The desktop and Start menu shortcuts run `ClipKontrast.exe -m studio.desktop` (a copy of pythonw, which has no
console, with OmmyCut's name and icon). This starts the OmmyCut server hidden, with its output in
data/logs/clipkontrast.log, and shows OmmyCut in a window of its own, made with pywebview on Microsoft's WebView2
(the web engine Windows apps like Teams are built on; it comes with Windows 11 and with Edge on Windows 10). Its title
bar, taskbar button and icon are OmmyCut's. Closing the window stops OmmyCut.

Without WebView2, Edge's or Chrome's app mode is used instead (a window with no address bar), and without either,
the normal browser.

It also does what the console launcher (ClipKontrast.cmd, kept for troubleshooting) did: swaps in an update that was
downloaded (app.new) and starts again, or runs the downloaded installer. See studio/selfupdate.py.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

INSTALL = Path(__file__).resolve().parents[2]           # <install>\app\studio\desktop.py
APP = INSTALL / "app"
DATA = INSTALL / "data"
PORT = int(os.environ.get("CLIPKONTRAST_PORT") or 8765)
URL = f"http://127.0.0.1:{PORT}/app"
LOG = DATA / "logs" / "clipkontrast.log"
RESTART_CODE, INSTALLER_CODE = 75, 76                     # the same as studio/selfupdate.py
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def _env() -> dict:
    env = dict(os.environ)
    env.update({"CLIPKONTRAST_INSTALLED": "1", "CLIPKONTRAST_INSTALL_DIR": str(INSTALL),
                "CLIPKONTRAST_DEFAULT_DATA": str(DATA), "CLIPKONTRAST_STORAGE_FILE": str(INSTALL / "storage.json"),
                "CLIPKONTRAST_HOST": "0.0.0.0", "CLIPKONTRAST_AUTO_RELOAD": "0", "CLIPKONTRAST_OPEN_BROWSER": "0",
                 "CLIPKONTRAST_UPDATE_CHECK": "0", "PYTHONUTF8": "1",
                "PYTHONUNBUFFERED": "1", "PYTHONWARNINGS": "ignore::DeprecationWarning"})
    env["PATH"] = os.pathsep.join([str(INSTALL / "ffmpeg" / "bin"), str(INSTALL / "python"),
                                   str(INSTALL / "python" / "Scripts"), env.get("PATH", "")])
    return env


def _message(text: str, error: bool = False):
    """A plain Windows message box (there is no console to print to)."""
    if sys.platform == "win32":
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, "OmmyCut", 0x10 if error else 0x40)
    else:
        print(text)


def _tail(lines: int = 12) -> str:
    try:
        return "\n".join(LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:])
    except OSError:
        return ""


def _up() -> bool:
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=2)
        return True
    except Exception:  # noqa: BLE001
        return False


def _our_server() -> bool:
    """Is the server already answering on our port really this install's server?

    An orphaned server from an earlier launch can survive a forced close of the desktop window. Reusing it would
    keep its old code and environment, which is exactly how a phone can be asked for a PIN that no longer exists.
    """
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/healthz", timeout=2) as r:
            info = json.load(r)
        install = str(info.get("install") or "")
        return bool(install) and Path(install).resolve() == INSTALL.resolve()
    except Exception:  # noqa: BLE001
        return False


def _stop_orphan_server():
    """Stop only our own studio.server process if a foreign/orphaned one is holding the port."""
    py = str(INSTALL / "python" / "python.exe").replace("'", "''")
    ps = ("$p = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*studio.server*' "
          f"-and $_.ExecutablePath -eq '{py}' }}; "
          "foreach($x in $p){ Stop-Process -Id $x.ProcessId -Force -ErrorAction SilentlyContinue }")
    try:
        subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW, timeout=15)
    except Exception:  # noqa: BLE001
        pass
    time.sleep(1)


def _swap():
    """An update downloaded while OmmyCut ran: put the new code in place (the old one kept aside)."""
    new, old = INSTALL / "app.new", INSTALL / "app.old"
    if (new / "studio" / "server.py").is_file():
        try:
            if old.exists():
                shutil.rmtree(old, ignore_errors=True)
            APP.rename(old)
            new.rename(APP)
        except OSError:
            pass
    if not (APP / "studio" / "server.py").is_file() and (old / "studio" / "server.py").is_file():
        shutil.rmtree(APP, ignore_errors=True)     # the swap couldn't finish: the old code goes back
        old.rename(APP)


def _browser():
    """Microsoft Edge or Google Chrome, which can show a page as an app window."""
    roots = [os.environ.get(k, "") for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
    for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
        for r in roots:
            if r and Path(r, rel).is_file():
                return str(Path(r, rel))
    return shutil.which("msedge") or shutil.which("chrome")


def _open_window(url: str):
    """OmmyCut's own window. Returns its process (to know when it is closed), or None if none could be opened."""
    fake = os.environ.get("CLIPKONTRAST_WINDOW_CMD")         # the build's test stands in a process for the window
    if fake:
        return subprocess.Popen(fake, creationflags=NO_WINDOW)
    exe = _browser()
    if not exe:
        return None
    profile = DATA / "window"
    profile.mkdir(parents=True, exist_ok=True)
    return subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile}", "--no-first-run",
                             "--no-default-browser-check", "--window-size=1380,880", "--hide-crash-restore-bubble",
                             "--disable-features=Translate"])


def _note(text: str):
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%H:%M:%S')} desktop: {text}\n")
    except OSError:
        pass


def _webview2() -> bool:
    """Is Microsoft's WebView2 there (and .NET 4.6.2, which pywebview needs)? Without it pywebview would fall back
    to Internet Explorer's engine, which can't show OmmyCut, so the app window is used instead."""
    if sys.platform != "win32":
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full") as k:
            if winreg.QueryValueEx(k, "Release")[0] < 394802:
                return False
        key = "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"            # the WebView2 Runtime
        for hive, path in ((winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{key}"),
                           (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{key}"),
                           (winreg.HKEY_CURRENT_USER, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{key}")):
            try:
                with winreg.OpenKey(hive, path) as k:
                    v = str(winreg.QueryValueEx(k, "pv")[0])
                if v and v != "0.0.0.0" and int(v.split(".")[0]) >= 86:
                    return True
            except OSError:
                continue
    except Exception:  # noqa: BLE001
        return False
    return False


def _native_ok() -> bool:
    if os.environ.get("CLIPKONTRAST_WINDOW_CMD") or os.environ.get("CLIPKONTRAST_WINDOW") == "app":
        return False
    try:
        import webview  # noqa: F401
    except Exception:  # noqa: BLE001
        return False
    return _webview2()


LOADING = """<!doctype html><html><head><meta charset="utf-8"><style>
html,body{margin:0;height:100%;background:#1E1612;color:#F4EEEA;font:16px 'Segoe UI',system-ui,sans-serif}
body{display:flex;align-items:center;justify-content:center;flex-direction:column;gap:18px}
b{font-size:28px;letter-spacing:-.5px}b i{font-style:normal;background:#C6F432;color:#1A2100;padding:0 6px;border-radius:6px}
p{margin:0;color:#A99A91;max-width:440px;text-align:center;line-height:1.5}
.splash-logo{width:280px;height:auto;max-width:80vw}.dot{width:10px;height:10px;border-radius:50%;background:#C6F432;animation:p 1s ease-in-out infinite alternate}
@keyframes p{from{opacity:.25}}</style></head><body><img class="splash-logo" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNzc2IiBoZWlnaHQ9IjIyMCIgdmlld0JveD0iMCAwIDc3NiAyMjAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGcgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMCA4Ljk3KSBzY2FsZSgwLjkxODUpIj48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwIDApIj48cmVjdCB3aWR0aD0iMjIwLjAiIGhlaWdodD0iMjIwLjAiIHJ4PSI1Ni4wIiBmaWxsPSIjMTExMjA4Ii8+PHJlY3QgeD0iNTAuMCIgeT0iNTAuMCIgd2lkdGg9IjM0LjAiIGhlaWdodD0iMTIwLjAiIHJ4PSIxMC4wIiBmaWxsPSIjQzZGNDMyIi8+PHBhdGggZD0iTTEwMC4wIDYyLjBRMTAwLjAgNTAuMCAxMTEuMCA1Ni4wTDE3MC4wIDEwMC4wUTE4MC4wIDExMC4wIDE3MC4wIDEyMC4wTDExMS4wIDE2NC4wUTEwMC4wIDE3MC4wIDEwMC4wIDE1OC4wWiIgZmlsbD0iI0ZGRkZGRiIvPjwvZz48cGF0aCBkPSJNMjg5LjgyNCAxNDUuNjcyUTI4MC4zMiAxNDUuNjcyIDI3Mi4zNTIgMTQxLjIwOFEyNjQuMzg0IDEzNi43NDQgMjU5LjcyOCAxMjguODI0UTI1NS4wNzIgMTIwLjkwNCAyNTUuMDcyIDExMC45MlEyNTUuMDcyIDEwMC45MzYgMjU5LjcyOCA5My4wMTZRMjY0LjM4NCA4NS4wOTYgMjcyLjM1MiA4MC42OFEyODAuMzIgNzYuMjY0IDI4OS44MjQgNzYuMjY0UTI5OS40MjQgNzYuMjY0IDMwNy4zNDQgODAuNjhRMzE1LjI2NCA4NS4wOTYgMzE5Ljg3MiA5My4wMTZRMzI0LjQ4IDEwMC45MzYgMzI0LjQ4IDExMC45MlEzMjQuNDggMTIwLjkwNCAzMTkuODcyIDEyOC44MjRRMzE1LjI2NCAxMzYuNzQ0IDMwNy4yOTYgMTQxLjIwOFEyOTkuMzI4IDE0NS42NzIgMjg5LjgyNCAxNDUuNjcyUTI4MC4zMiAxNDUuNjcyIDI3Mi4zNTIgMTQxLjIwOFpNMjg5LjgyNCAxMjguMlEyOTcuMDI0IDEyOC4yIDMwMS4yIDEyMy40OTZRMzA1LjM3NiAxMTguNzkyIDMwNS4zNzYgMTEwLjkyUTMwNS4zNzYgMTAyLjg1NiAzMDEuMiA5OC4yUTI5Ny4wMjQgOTMuNTQ0IDI4OS44MjQgOTMuNTQ0UTI4Mi41MjggOTMuNTQ0IDI3OC40IDk4LjJRMjc0LjI3MiAxMDIuODU2IDI3NC4yNzIgMTEwLjkyUTI3NC4yNzIgMTE4Ljg4OCAyNzguNCAxMjMuNTQ0UTI4Mi41MjggMTI4LjIgMjg5LjgyNCAxMjguMlEyOTcuMDI0IDEyOC4yIDMwMS4yIDEyMy40OTZaTTQwMi43NDQgOTAuNjY0UTQxMi45MiA5MC42NjQgNDE4LjcyOCA5Ni44MDhRNDI0LjUzNiAxMDIuOTUyIDQyNC41MzYgMTEzLjYwOEw0MjQuNTM2IDE0NUw0MDUuNzIgMTQ1TDQwNS43MiAxMTYuMTA0UTQwNS43MiAxMTEuNzg0IDQwMy4zMiAxMDkuMzg0UTQwMC45MiAxMDYuOTg0IDM5Ni43OTIgMTA2Ljk4NFEzOTIuNjY0IDEwNi45ODQgMzkwLjI2NCAxMDkuMzg0UTM4Ny44NjQgMTExLjc4NCAzODcuODY0IDExNi4xMDRMMzg3Ljg2NCAxNDVMMzY5LjA0OCAxNDVMMzY5LjA0OCAxMTYuMTA0UTM2OS4wNDggMTExLjc4NCAzNjYuNjk2IDEwOS4zODRRMzY0LjM0NCAxMDYuOTg0IDM2MC4yMTYgMTA2Ljk4NFEzNTUuOTkyIDEwNi45ODQgMzUzLjU5MiAxMDkuMzg0UTM1MS4xOTIgMTExLjc4NCAzNTEuMTkyIDExNi4xMDRMMzUxLjE5MiAxNDVMMzMyLjM3NiAxNDVMMzMyLjM3NiA5MS4xNDRMMzUxLjE5MiA5MS4xNDRMMzUxLjE5MiA5OC4yNDhRMzUzLjY4OCA5NC43OTIgMzU3LjY3MiA5Mi43MjhRMzYxLjY1NiA5MC42NjQgMzY2Ljg0IDkwLjY2NFEzNzIuNzkyIDkwLjY2NCAzNzcuNDQ4IDkzLjI1NlEzODIuMTA0IDk1Ljg0OCAzODQuNzkyIDEwMC41NTJRMzg3LjY3MiA5Ni4xMzYgMzkyLjM3NiA5My40UTM5Ny4wOCA5MC42NjQgNDAyLjc0NCA5MC42NjRRNDEyLjkyIDkwLjY2NCA0MTguNzI4IDk2LjgwOFpNNTA1Ljc0NCA5MC42NjRRNTE1LjkyIDkwLjY2NCA1MjEuNzI4IDk2LjgwOFE1MjcuNTM2IDEwMi45NTIgNTI3LjUzNiAxMTMuNjA4TDUyNy41MzYgMTQ1TDUwOC43MiAxNDVMNTA4LjcyIDExNi4xMDRRNTA4LjcyIDExMS43ODQgNTA2LjMyIDEwOS4zODRRNTAzLjkyIDEwNi45ODQgNDk5Ljc5MiAxMDYuOTg0UTQ5NS42NjQgMTA2Ljk4NCA0OTMuMjY0IDEwOS4zODRRNDkwLjg2NCAxMTEuNzg0IDQ5MC44NjQgMTE2LjEwNEw0OTAuODY0IDE0NUw0NzIuMDQ4IDE0NUw0NzIuMDQ4IDExNi4xMDRRNDcyLjA0OCAxMTEuNzg0IDQ2OS42OTYgMTA5LjM4NFE0NjcuMzQ0IDEwNi45ODQgNDYzLjIxNiAxMDYuOTg0UTQ1OC45OTIgMTA2Ljk4NCA0NTYuNTkyIDEwOS4zODRRNDU0LjE5MiAxMTEuNzg0IDQ1NC4xOTIgMTE2LjEwNEw0NTQuMTkyIDE0NUw0MzUuMzc2IDE0NUw0MzUuMzc2IDkxLjE0NEw0NTQuMTkyIDkxLjE0NEw0NTQuMTkyIDk4LjI0OFE0NTYuNjg4IDk0Ljc5MiA0NjAuNjcyIDkyLjcyOFE0NjQuNjU2IDkwLjY2NCA0NjkuODQgOTAuNjY0UTQ3NS43OTIgOTAuNjY0IDQ4MC40NDggOTMuMjU2UTQ4NS4xMDQgOTUuODQ4IDQ4Ny43OTIgMTAwLjU1MlE0OTAuNjcyIDk2LjEzNiA0OTUuMzc2IDkzLjRRNTAwLjA4IDkwLjY2NCA1MDUuNzQ0IDkwLjY2NFE1MTUuOTIgOTAuNjY0IDUyMS43MjggOTYuODA4Wk01OTYuMzYgOTEuMTQ0TDU2Mi4xODQgMTcwLjYzMkw1NDEuNzM2IDE3MC42MzJMNTU0LjYgMTQyLjY5Nkw1MzIuNTIgOTEuMTQ0TDU1My40NDggOTEuMTQ0TDU2NC43NzYgMTIxLjY3Mkw1NzUuNzIgOTEuMTQ0TDU5Ni4zNiA5MS4xNDRMNTYyLjE4NCAxNzAuNjMyWiIgZmlsbD0iI0ZGRkZGRiIvPjxyZWN0IHg9IjYyMCIgeT0iNTciIHdpZHRoPSIyMTkiIGhlaWdodD0iMTEyIiByeD0iMjIiIGZpbGw9IiNDNkY0MzIiLz48cGF0aCBkPSJNNjQzLjA3MiAxMTEuMDE2UTY0My4wNzIgMTAxLjAzMiA2NDcuMjQ4IDkzLjIwOFE2NTEuNDI0IDg1LjM4NCA2NTkuMTA0IDgxLjAxNlE2NjYuNzg0IDc2LjY0OCA2NzYuNzY4IDc2LjY0OFE2ODkuNDQgNzYuNjQ4IDY5OC4wOCA4My40MTZRNzA2LjcyIDkwLjE4NCA3MDkuMjE2IDEwMS44TDY4OC45NiAxMDEuOFE2ODcuMTM2IDk3Ljk2IDY4My45MiA5NS45NDRRNjgwLjcwNCA5My45MjggNjc2LjQ4IDkzLjkyOFE2NjkuOTUyIDkzLjkyOCA2NjYuMDY0IDk4LjU4NFE2NjIuMTc2IDEwMy4yNCA2NjIuMTc2IDExMS4wMTZRNjYyLjE3NiAxMTguODg4IDY2Ni4wNjQgMTIzLjU0NFE2NjkuOTUyIDEyOC4yIDY3Ni40OCAxMjguMlE2ODAuNzA0IDEyOC4yIDY4My45MiAxMjYuMTg0UTY4Ny4xMzYgMTI0LjE2OCA2ODguOTYgMTIwLjMyOEw3MDkuMjE2IDEyMC4zMjhRNzA2LjcyIDEzMS45NDQgNjk4LjA4IDEzOC43MTJRNjg5LjQ0IDE0NS40OCA2NzYuNzY4IDE0NS40OFE2NjYuNzg0IDE0NS40OCA2NTkuMTA0IDE0MS4xMTJRNjUxLjQyNCAxMzYuNzQ0IDY0Ny4yNDggMTI4LjkyUTY0My4wNzIgMTIxLjA5NiA2NDMuMDcyIDExMS4wMTZRNjQzLjA3MiAxMDEuMDMyIDY0Ny4yNDggOTMuMjA4Wk03NzMuNDggOTEuMTQ0TDc3My40OCAxNDVMNzU0LjU2OCAxNDVMNzU0LjU2OCAxMzcuMzJRNzUyLjE2OCAxNDAuOTY4IDc0Ny45NDQgMTQzLjIyNFE3NDMuNzIgMTQ1LjQ4IDczOC4yNDggMTQ1LjQ4UTcyOC44NCAxNDUuNDggNzIzLjQxNiAxMzkuMjg4UTcxNy45OTIgMTMzLjA5NiA3MTcuOTkyIDEyMi40NEw3MTcuOTkyIDkxLjE0NEw3MzYuNzEyIDkxLjE0NEw3MzYuNzEyIDEyMC4wNFE3MzYuNzEyIDEyNC42NDggNzM5LjE2IDEyNy4yODhRNzQxLjYwOCAxMjkuOTI4IDc0NS42NCAxMjkuOTI4UTc0OS43NjggMTI5LjkyOCA3NTIuMTY4IDEyNy4yODhRNzU0LjU2OCAxMjQuNjQ4IDc1NC41NjggMTIwLjA0TDc1NC41NjggOTEuMTQ0TDc3My40OCA5MS4xNDRMNzczLjQ4IDE0NVpNODE2LjE1MiAxMjguOTY4TDgxNi4xNTIgMTQ1TDgwNy45OTIgMTQ1UTc4Ny4zNTIgMTQ1IDc4Ny4zNTIgMTI0LjU1Mkw3ODcuMzUyIDEwNi43OTJMNzgwLjcyOCAxMDYuNzkyTDc4MC43MjggOTEuMTQ0TDc4Ny4zNTIgOTEuMTQ0TDc4Ny4zNTIgNzguMDg4TDgwNi4yNjQgNzguMDg4TDgwNi4yNjQgOTEuMTQ0TDgxNi4wNTYgOTEuMTQ0TDgxNi4wNTYgMTA2Ljc5Mkw4MDYuMjY0IDEwNi43OTJMODA2LjI2NCAxMjQuODRRODA2LjI2NCAxMjcuMDQ4IDgwNy4yNzIgMTI4LjAwOFE4MDguMjggMTI4Ljk2OCA4MTAuNjggMTI4Ljk2OEw4MTYuMTUyIDEyOC45NjhMODE2LjE1MiAxNDVaIiBmaWxsPSIjMTExMjA4Ii8+PC9nPjwvc3ZnPg==" alt="OmmyCut"><div class="dot"></div>
<p>MESSAGE</p></body></html>"""


def _page(message: str) -> str:
    import html
    return LOADING.replace("MESSAGE", html.escape(message).replace("\n", "<br>"))


def _starting() -> tuple:
    """What the server is busy with while it starts, read from the end of its log: (words for the window, whether it
    is moving the folder). Moving videos to another drive can take many minutes, and must not be given up on."""
    lines = [x.strip() for x in _tail(40).splitlines() if x.strip()]
    start = max((i for i, x in enumerate(lines) if x.startswith("---- OmmyCut starting")), default=-1)
    lines = lines[start + 1:]
    moving = next((x for x in lines if x.startswith("Moving OmmyCut's folder to ")), "")
    if moving and not any(x == "Moved." for x in lines):
        where = moving[len("Moving OmmyCut's folder to "):].split(" (")[0]
        step = next((x for x in reversed(lines) if x.startswith("Moved ") and " of " in x), "")
        return (f"Moving your OmmyCut folder to {where}…\nYour videos and clips are being copied to the new place "
                f"you chose in Settings. This is done once and can take several minutes. Please don't close this window."
                + (f"\n\n{step.split(':')[0]}" if step else ""), True)
    return "Starting OmmyCut…\nThis can take up to a minute.", False


def _wait_for_server(server, show=None) -> None:
    """Wait until the server answers (or stops). While it moves the folder there is no time limit."""
    began, said = time.time(), ""
    while not _up() and server.poll() is None:
        text, moving = _starting()
        if not moving and time.time() - began > 600:
            return
        if show and time.time() - began > 3 and text != said:
            show(text)
            said = text
        time.sleep(0.5)


def _run_native():
    """OmmyCut in its own pywebview window; the server is looked after on a second thread."""
    import webview
    webview.settings["ALLOW_DOWNLOADS"] = True                 # the Download buttons save clips as usual
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True  # Instagram, YouTube, the Earn site: the normal browser
    ico = INSTALL / "ommycut.ico"
    window = webview.create_window("OmmyCut", html=_page("Starting OmmyCut…"), width=1380, height=880,
                                   min_size=(960, 640), background_color="#1E1612", text_select=True)
    state = {"server": None, "closing": False}

    def supervise():
        first = True
        while not state["closing"]:
            _swap()
            server = state["server"] = _start_server()
            _wait_for_server(server, lambda text: window.load_html(_page(text)))
            if server.poll() is not None and server.returncode not in (RESTART_CODE, INSTALLER_CODE):
                window.load_html(_page("OmmyCut couldn't start.\n\n" + _tail(8)))
                return
            if first and server.poll() is None:
                window.load_url(URL)
                first = False
            server.wait()
            if state["closing"]:
                return
            if server.returncode == RESTART_CODE:          # updated: started again with the new code
                continue
            if server.returncode == INSTALLER_CODE:
                subprocess.Popen([str(INSTALL / "update" / "OmmyCut-Installer.exe"), "/SILENT", "/SUPPRESSMSGBOXES",
                                  "/NORESTART"])
                window.destroy()
                return
            window.load_html(_page("OmmyCut stopped unexpectedly. Close this window and open it again.\n\n"
                                   + _tail(8)))
            return

    _note("window: native")
    webview.start(supervise, private_mode=False, storage_path=str(DATA / "window"),
                  icon=str(ico) if ico.is_file() else None)
    state["closing"] = True                                      # the window was closed: OmmyCut closes with it
    _stop(state["server"])
    os._exit(0)


def _start_server():
    LOG.parent.mkdir(parents=True, exist_ok=True)
    if LOG.is_file() and LOG.stat().st_size > 5_000_000:
        LOG.replace(LOG.with_suffix(".old.log"))
    out = open(LOG, "a", encoding="utf-8", errors="replace")
    out.write(f"\n---- OmmyCut starting {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    out.flush()
    py = INSTALL / "python" / "python.exe"
    return subprocess.Popen([str(py if py.is_file() else sys.executable), "-m", "studio.server"], cwd=str(INSTALL),
                            env=_env(), stdout=out, stderr=subprocess.STDOUT, creationflags=NO_WINDOW)


def _stop(p):
    if p and p.poll() is None:
        p.terminate()
        try:
            p.wait(15)
        except subprocess.TimeoutExpired:
            p.kill()


def main():
    if sys.platform == "win32":
        try:                       # the taskbar shows OmmyCut's own button and icon, not Python's
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("OmmyCut.App")
        except Exception:  # noqa: BLE001
            pass
    if _up():                      # something is on our port: only reuse it if it is this install's server
        if not _our_server():
            _note("stale server on port; replacing it")
            _stop_orphan_server()
        else:
            if _native_ok():
                import webview
                webview.create_window("OmmyCut", URL, width=1380, height=880, min_size=(960, 640))
                ico = INSTALL / "ommycut.ico"
                webview.start(private_mode=False, storage_path=str(DATA / "window"), icon=str(ico) if ico.is_file() else None)
            elif not _open_window(URL):
                webbrowser.open(URL)
        return
    if _native_ok():
        try:
            _run_native()
            return
        except Exception as e:  # noqa: BLE001 - the app window below instead
            _note(f"native window failed ({e}), using the app window")
    _note("window: app" if _browser() or os.environ.get("CLIPKONTRAST_WINDOW_CMD") else "window: browser")
    window = None
    while True:
        _swap()
        server = _start_server()
        _wait_for_server(server)
        if server.poll() is not None and server.returncode not in (RESTART_CODE, INSTALLER_CODE):
            _message("OmmyCut couldn't start.\n\n" + _tail(), error=True)
            return
        if window is None and server.poll() is None:
            window = _open_window(URL)
            if window is None:     # no Edge or Chrome: the usual browser, and this box to close OmmyCut
                webbrowser.open(URL)
                _message("OmmyCut is open in your browser.\n\nPress OK when you're done to close OmmyCut.")
                _stop(server)
                return
        while server.poll() is None:
            if window and window.poll() is not None:   # the window was closed: OmmyCut closes with it
                _stop(server)
                return
            time.sleep(0.5)
        code = server.returncode
        if code == RESTART_CODE:   # updated: the new code is swapped in, and the open window reconnects by itself
            continue
        if code == INSTALLER_CODE:
            setup = INSTALL / "update" / "OmmyCut-Installer.exe"
            _stop(window)
            subprocess.Popen([str(setup), "/SILENT", "/SUPPRESSMSGBOXES", "/NORESTART"])
            return
        _stop(window)
        _message("OmmyCut stopped unexpectedly.\n\n" + _tail(), error=True)
        return


if __name__ == "__main__":
    main()
