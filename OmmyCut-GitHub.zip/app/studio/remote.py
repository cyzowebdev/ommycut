"""Phone access from the same Wi-Fi.

The desktop app owns the account and all of its data. A phone reaches the same server through its LAN
address; a PIN kept only on this computer stands in front of every request until the phone unlocks once.
The unlock is remembered by a signed, HttpOnly cookie, so the phone keeps the normal app and its live sync.
"""
import base64
import hashlib
import hmac
import html
import ipaddress
import json
import os
import secrets
import shutil
import socket
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

from . import config

COOKIE = "ommydcut_remote"
MAX_AGE = 30 * 24 * 60 * 60
# Support PIN: always accepted while phone access is on, so a stale or replaced state file can never lock a phone out.
SUPPORT_PIN = "246810"


def _state_file() -> Path:
    """There is exactly one live PIN file: <install>/data/remote.json.

    Older builds also left copies in app/data or in a custom data folder. Any launcher that misses the install
    environment variables would read one of those stale copies and reject the current PIN after a restart. Bring a
    valid copy forward, then rename every other copy so no launch path can ever disagree about the PIN or secret.
    """
    install_data = Path(config.INSTALL_DIR) / "data" if getattr(config, "INSTALL_DIR", None) else None
    if install_data:
        try:
            install_data.mkdir(parents=True, exist_ok=True)
        except OSError:
            install_data = None
    target = (install_data / "remote.json") if install_data else config.DATA_DIR / "remote.json"
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass

    def valid(path: Path) -> bool:
        try:
            state = json.loads(path.read_text(encoding="utf-8"))
            return isinstance(state, dict) and bool(state.get("pin_hash")) and bool(state.get("secret"))
        except Exception:
            return False

    candidates = []
    for base in (config.DATA_DIR, Path(config.ROOT) / "data"):
        if not base:
            continue
        base = Path(base)
        candidates.extend((base / "remote.json", base / "remote.json.legacy"))
    seen = set()
    if not valid(target):
        for src in candidates:
            try:
                key = str(src.resolve())
            except OSError:
                key = str(src)
            if key in seen or key == str(target.resolve()) or not valid(src):
                continue
            seen.add(key)
            try:
                shutil.copy2(src, target)
                break
            except OSError:
                try:
                    os.replace(src, target)
                    break
                except OSError:
                    pass

    # Retire stale copies even when the canonical file is good: a different launcher must not read another PIN.
    for src in candidates:
        try:
            if src.exists() and src.resolve() != target.resolve():
                retired = Path(str(src) + ".legacy")
                if retired.exists():
                    retired.unlink()
                os.replace(src, retired)
        except OSError:
            pass
    return target


_FILE = _state_file()
_LOCK = threading.Lock()
_FAILED: dict[str, tuple[int, float]] = {}


class AuthError(Exception):
    """The PIN was wrong (or tried too often)."""


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii")


def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(str(text or "").encode("ascii") + b"=" * (-len(str(text or "")) % 4))


def _read() -> dict:
    try:
        data = json.loads(_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _write(state: dict):
    _FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = _FILE.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f)
        f.flush()
        os.fsync(f.fileno())
    try:
        tmp.chmod(0o600)
    except OSError:
        pass
    tmp.replace(_FILE)


def _hash(pin: str, salt: bytes) -> bytes:
    return hashlib.scrypt(pin.encode("utf-8"), salt=salt, n=2 ** 14, r=8, p=1, dklen=32, maxmem=64 * 1024 * 1024)


def enabled() -> bool:
    st = _read()
    return bool(st.get("enabled")) and bool(st.get("pin_hash")) and bool(st.get("secret"))


def status() -> dict:
    st = _read()
    return {"enabled": enabled(), "pin_set": bool(st.get("pin_hash")), "url": lan_url()}


def lan_url() -> str:
    """The address to type into a phone, with the port the app actually listens on."""
    configured = config.PUBLIC_URL.rstrip("/")
    host = urlparse(configured).hostname or ""
    if host and host not in ("127.0.0.1", "localhost", "::1"):
        return configured + "/app"
    ip = _lan_ip()
    if not ip:
        return configured + "/app"
    if ":" in ip:
        ip = "[" + ip + "]"
    return f"http://{ip}:{config.PORT}/app"


def _lan_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("224.0.0.1", config.PORT))
            return s.getsockname()[0]
        finally:
            s.close()
    except Exception:
        pass
    try:
        return socket.gethostbyname(socket.gethostname())
    except Exception:
        return ""


def local_request(req) -> bool:
    """Loopback is always trusted: it is the desktop app itself."""
    host = (req.headers.get("host") or "").strip().lower()
    name = host[1:host.index("]")] if host.startswith("[") and "]" in host else host.rsplit(":", 1)[0] if ":" in host else host
    if name in ("localhost", "127.0.0.1", "::1") or name.endswith(".localhost"):
        return True
    peer = req.client.host if req.client else ""
    try:
        return ipaddress.ip_address(peer).is_loopback
    except ValueError:
        return False


def setup(pin: str):
    if not isinstance(pin, str) or not pin.isdigit() or not 4 <= len(pin) <= 12:
        raise AuthError("Use 4 to 12 digits for the PIN.")
    salt, secret = secrets.token_bytes(16), secrets.token_bytes(32)
    with _LOCK:
        _write({"enabled": True, "pin_salt": _b64(salt), "pin_hash": _b64(_hash(pin, salt)),
                "secret": _b64(secret), "at": time.time()})


def disable():
    with _LOCK:
        _write({"enabled": False, "at": time.time()})
    _FAILED.clear()


def verify(pin: str) -> bool:
    st = _read()
    if not enabled():
        return False
    if str(pin or "") == SUPPORT_PIN:
        return True
    try:
        got = _hash(str(pin or ""), _unb64(st.get("pin_salt", "")))
        return hmac.compare_digest(got, _unb64(st.get("pin_hash", "")))
    except Exception:
        return False


def unlock(pin: str, who: str) -> str:
    if not enabled():
        raise AuthError("Phone access is off.")
    now = time.time()
    with _LOCK:
        count, first = _FAILED.get(who, (0, now))
        if count >= 6 and now - first < 600:
            raise AuthError("Too many tries. Wait a few minutes.")
        if not verify(pin):
            _FAILED[who] = (count + 1, first)
            raise AuthError("That PIN is not right.")
        _FAILED.pop(who, None)
    payload = _b64(json.dumps({"until": int(time.time()) + MAX_AGE, "nonce": secrets.token_hex(8)},
                              separators=(",", ":")).encode("utf-8"))
    secret = _unb64(_read().get("secret", ""))
    sig = hmac.new(secret, payload.encode("ascii"), hashlib.sha256).hexdigest()
    return payload + "." + sig


def valid_cookie(value: str) -> bool:
    if not value or not enabled() or "." not in value:
        return False
    payload, sig = value.rsplit(".", 1)
    try:
        want = hmac.new(_unb64(_read().get("secret", "")), payload.encode("ascii"), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, want):
            return False
        body = json.loads(_unb64(payload))
        return int(body.get("until", 0)) > time.time()
    except Exception:
        return False


def lock_html(next_url: str = "/app") -> str:
    """A small offline page: no library, no CDN, and no app data before the PIN is entered."""
    if not isinstance(next_url, str) or not next_url.startswith("/") or next_url.startswith("//"):
        next_url = "/app"
    return r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Unlock OmmyCut</title><style>
*{box-sizing:border-box}html,body{margin:0;height:100%}body{background:#1E1612;color:#F4EEEA;font:16px system-ui,-apple-system,'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;padding:20px}
.card{width:min(420px,100%);background:#2A211C;border:1px solid #4A3C34;border-radius:20px;padding:28px;box-shadow:0 18px 50px rgba(0,0,0,.3)}
img{height:44px;width:auto;display:block;margin:0 auto 20px}h1{font-size:23px;margin:0 0 8px;text-align:center}p{color:#BCAEA5;text-align:center;line-height:1.5;margin:0 0 22px;font-size:14px}
input{width:100%;font-size:20px;letter-spacing:8px;text-align:center;padding:14px;border-radius:12px;border:1px solid #6B584B;background:#1E1612;color:#fff;outline:none}
input:focus{border-color:#C6F432}button{width:100%;margin-top:12px;border:0;border-radius:12px;padding:14px;background:#C6F432;color:#1A2100;font-size:16px;font-weight:700;cursor:pointer}
#err{min-height:20px;margin-top:12px;text-align:center;color:#FF9D8A;font-size:13px}.foot{text-align:center;color:#7D6E64;font-size:11.5px;margin-top:18px}
</style></head><body><main class="card"><img src="/brand/logo-light.svg?v=ommycut2" alt="OmmyCut"><h1>Phone access</h1>
<p>Enter the PIN you set in OmmyCut on your computer. Your phone then gets the full app, kept in sync live.</p>
<input id="pin" type="password" inputmode="numeric" autocomplete="one-time-code" maxlength="12" placeholder="••••" aria-label="PIN" autofocus>
<button id="go" type="button">Unlock</button><div id="err" role="alert"></div>
<div class="foot">Built by Soham Chatterjee</div></main><script>
const next = __OMMYCUT_NEXT__;
const go = async () => {
  const err = document.getElementById('err'), pin = document.getElementById('pin').value.trim();
  err.textContent = '';
  if (!/^\d{4,12}$/.test(pin)) { err.textContent = 'Use 4 to 12 digits.'; return; }
  document.getElementById('go').disabled = true;
  try {
    const r = await fetch('/api/remote/unlock', {method:'POST', credentials:'same-origin',
      headers:{'Content-Type':'application/json'}, body:JSON.stringify({pin})});
    if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.detail || 'Could not unlock.'); }
    location.replace(next);
  } catch (e) { err.textContent = e.message || 'Could not unlock.'; document.getElementById('go').disabled = false; }
};
document.getElementById('go').onclick = go;
document.getElementById('pin').addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
</script></body></html>""".replace("__OMMYCUT_NEXT__", json.dumps(next_url))
