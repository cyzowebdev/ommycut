$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent $Here
$Out = Join-Path $Root "OmmyCut-Installer.exe"
$Source = Join-Path $Here "InstallerApp.cs"
$Install = Join-Path $Here "install.ps1"
$Icon = Join-Path $Root "ommycut.ico"
$Splash = Join-Path $Here "splash-logo.png"

$Manifest = Join-Path $Here "app.manifest"

$compilers = @(
    (Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
    (Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe")
)
$Csc = $compilers | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $Csc) { throw "A .NET Framework C# compiler (csc.exe) was not found on this PC." }

foreach ($file in @($Source, $Install, $Icon, $Splash, $Manifest)) {
    if (-not (Test-Path $file)) { throw "Missing build input: $file" }
}

if (Test-Path $Out) { Remove-Item $Out -Force }

$refs = @(
    "/r:System.dll",
    "/r:System.Core.dll",
    "/r:System.Drawing.dll",
    "/r:System.Windows.Forms.dll"
)
& $Csc /nologo /target:winexe /platform:anycpu /optimize+ /debug- `
    /main:OmmyCutInstaller.Program `
    /win32icon:"$Icon" `
    /win32manifest:"$Manifest" `
    /resource:"$Install,install.ps1" `
    /resource:"$Splash,splash.png" `
    /out:"$Out" $refs $Source
if ($LASTEXITCODE -ne 0 -or -not (Test-Path $Out)) { throw "The OmmyCut installer bootstrapper did not build." }

Write-Host "Built $Out"
Get-Item $Out | Select-Object FullName, Length
