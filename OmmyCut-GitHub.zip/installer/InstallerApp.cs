using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

[assembly: AssemblyTitle("OmmyCut installer")]
[assembly: AssemblyDescription("Downloads and installs OmmyCut")]
[assembly: AssemblyCompany("Soham Chatterjee")]
[assembly: AssemblyProduct("OmmyCut")]
[assembly: AssemblyCopyright("Soham Chatterjee")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace OmmyCutInstaller
{
    internal class Splash : Form
    {
        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();

        private readonly Timer clock;
        private bool preview;
        private readonly PointF[] motes = new PointF[30];
        private Image logo;
        private Process child;
        private string tempDir = "";
        private string status = "Getting OmmyCut ready...";
        private string detail = "Preparing the installer.";
        private string errorText = "";
        private int progress = 4;
        private int frame;
        private int closeAt = -1;
        private bool done;
        private bool failed;

        public Splash(bool previewMode)
        {
            preview = previewMode;
            Text = "OmmyCut installer";
            ClientSize = new Size(820, 500);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = true;
            BackColor = Color.FromArgb(20, 15, 12);
            DoubleBuffered = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
            Region = new Region(RoundRect(new Rectangle(0, 0, Width, Height), 22));

            Random rnd = new Random(1108);
            for (int i = 0; i < motes.Length; i++)
                motes[i] = new PointF((float)rnd.NextDouble(), (float)rnd.NextDouble());

            clock = new Timer();
            clock.Interval = 16;
            clock.Tick += ClockTick;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            try
            {
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("splash.png"))
                {
                    if (s == null) throw new FileNotFoundException("splash.png");
                    logo = new Bitmap(Image.FromStream(s));
                }
            }
            catch (Exception ex)
            {
                errorText = ex.Message;
            }

            clock.Start();
            if (preview)
            {
                status = "Previewing the OmmyCut installer";
                detail = "This animation appears when the installer runs.";
                progress = 8;
            }
            else
            {
                StartInstall();
            }
        }

        private void StartInstall()
        {
            try
            {
                tempDir = Path.Combine(Path.GetTempPath(), "ommycut-bootstrap-" + Guid.NewGuid().ToString("N"));
                Directory.CreateDirectory(tempDir);
                string script = Path.Combine(tempDir, "install.ps1");

                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream("install.ps1"))
                {
                    if (s == null) throw new FileNotFoundException("install.ps1");
                    using (StreamReader reader = new StreamReader(s))
                        File.WriteAllText(script, reader.ReadToEnd());
                }

                string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),
                                                 "WindowsPowerShell", "v1.0", "powershell.exe");
                if (!File.Exists(powershell)) powershell = "powershell.exe";

                ProcessStartInfo psi = new ProcessStartInfo();
                psi.FileName = powershell;
                psi.Arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"" + script + "\" -NoPrompt";
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;

                child = new Process();
                child.StartInfo = psi;
                child.EnableRaisingEvents = true;
                child.OutputDataReceived += ChildOutput;
                child.ErrorDataReceived += ChildOutput;
                child.Exited += ChildExited;
                child.Start();
                child.BeginOutputReadLine();
                child.BeginErrorReadLine();
                status = "Downloading OmmyCut from GitHub";
                detail = "Fetching the clean source archive.";
                progress = 14;
            }
            catch (Exception ex)
            {
                Fail("The installer could not start PowerShell: " + ex.Message);
            }
        }

        private void ChildOutput(object sender, DataReceivedEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(e.Data)) return;
            Ui(delegate { HandleLog(e.Data); });
        }

        private void ChildExited(object sender, EventArgs e)
        {
            int code = -1;
            try { code = child.ExitCode; } catch { }
            Ui(delegate
            {
                if (code == 0) Finish(true);
                else if (!failed) Fail("The install stopped before OmmyCut was ready. Exit code " + code + ".");
            });
            try { Directory.Delete(tempDir, true); } catch { }
        }

        private void HandleLog(string raw)
        {
            if (failed || done) return;
            string line = raw.Trim();
            if (line.StartsWith("["))
            {
                int close = line.IndexOf(']');
                if (close > 0) line = line.Substring(close + 1).Trim();
            }
            if (line.Length == 0) return;

            string low = line.ToLowerInvariant();
            if (low.Contains("not published") || low.Contains("not a valid ommycut zip"))
            {
                errorText = "OmmyCut is not published on GitHub yet.";
                status = "Waiting for the GitHub repo";
                detail = "Upload the repo, then run this installer again.";
                failed = true;
                Cursor = Cursors.Hand;
                return;
            }
            if (low.Contains("error:") || low.StartsWith("error"))
            {
                errorText = line;
                Fail(line);
                return;
            }
            if (low.Contains("downloading"))
            {
                status = "Downloading OmmyCut from GitHub";
                progress = Math.Max(progress, 16);
            }
            else if (low.Contains("installing ommycut files") || low.Contains("installing ommycut"))
            {
                status = "Installing OmmyCut files";
                progress = Math.Max(progress, 34);
            }
            else if (low.Contains("python runtime") || low.Contains("installing pip") || low.Contains("python packages"))
            {
                status = "Installing the private runtime";
                progress = Math.Max(progress, 54);
            }
            else if (low.Contains("ffmpeg"))
            {
                status = "Installing ffmpeg";
                progress = Math.Max(progress, 70);
            }
            else if (low.Contains("creating ommyc ut shortcuts") || low.Contains("creating ommycut shortcuts"))
            {
                status = "Creating Desktop and Start menu shortcuts";
                progress = Math.Max(progress, 86);
            }
            else if (low.Contains("starting ommycut"))
            {
                status = "Starting OmmyCut";
                progress = Math.Max(progress, 94);
            }
            else if (low.Contains("installed successfully") || low.Contains("done. ommycut"))
            {
                Finish(true);
                return;
            }
            detail = line.Length > 96 ? line.Substring(0, 93) + "..." : line;
        }

        private void Finish(bool ok)
        {
            if (done || failed) return;
            if (ok)
            {
                status = "OmmyCut is ready";
                detail = "Desktop and Start menu shortcuts are set.";
                progress = 100;
                done = true;
                closeAt = frame + 85;
            }
            else
            {
                Fail("The installer finished, but OmmyCut did not start.");
            }
        }

        private void Fail(string message)
        {
            if (failed || done) return;
            failed = true;
            try { if (child != null && !child.HasExited) child.Kill(); } catch { }
            errorText = String.IsNullOrEmpty(message) ? "Something went wrong." : message;
            status = "Install needs attention";
            detail = errorText.Length > 110 ? errorText.Substring(0, 107) + "..." : errorText;
            Cursor = Cursors.Hand;
        }

        private void Ui(Action action)
        {
            try
            {
                if (IsHandleCreated && !IsDisposed) BeginInvoke(action);
            }
            catch { }
        }

        private void ClockTick(object sender, EventArgs e)
        {
            frame++;
            if (preview)
            {
                int p = 8 + (int)Math.Min(88, (frame - 8) * 0.33);
                progress = Math.Max(8, Math.Min(96, p));
                string[] phases = {
                    "Downloading OmmyCut from GitHub",
                    "Installing OmmyCut files",
                    "Installing the private runtime",
                    "Installing ffmpeg",
                    "Creating Desktop and Start menu shortcuts",
                    "Starting OmmyCut"
                };
                status = phases[Math.Min(phases.Length - 1, Math.Max(0, (frame / 55) % phases.Length))];
                detail = "Smooth, branded installation with live progress.";
                if (frame > 340)
                {
                    progress = 100;
                    status = "OmmyCut is ready";
                    detail = "This preview closes by itself.";
                    done = true;
                    preview = false;
                    closeAt = frame + 75;
                }
            }
            if (done && closeAt > 0 && frame >= closeAt)
            {
                Close();
                return;
            }
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            Rectangle all = new Rectangle(0, 0, Width, Height);
            using (LinearGradientBrush bg = new LinearGradientBrush(all,
                Color.FromArgb(37, 27, 22), Color.FromArgb(16, 12, 10), LinearGradientMode.Vertical))
                g.FillRectangle(bg, all);

            double t = frame / 60.0;
            for (int i = 0; i < 3; i++)
            {
                float x = (float)(Width * (0.22 + 0.28 * i) + 70 * Math.Sin(t * 0.5 + i));
                float y = (float)(110 + 55 * Math.Cos(t * 0.6 + i * 1.7));
                using (SolidBrush glow = new SolidBrush(Color.FromArgb(12, 198, 244, 50)))
                    g.FillEllipse(glow, x - 120, y - 120, 240, 240);
            }

            int cx = Width / 2;
            Rectangle orbit = new Rectangle(cx - 268, 80, 536, 166);
            using (Pen ring = new Pen(Color.FromArgb(45, 198, 244, 50), 1f))
                g.DrawEllipse(ring, orbit);
            using (Pen spin = new Pen(Color.FromArgb(210, 198, 244, 50), 2f))
            {
                spin.DashStyle = DashStyle.Dash;
                g.DrawArc(spin, orbit, (float)(-90 + t * 42), 62);
                g.DrawArc(spin, Rectangle.Inflate(orbit, -14, -8), (float)(90 + t * 34), 44);
            }

            for (int i = 0; i < motes.Length; i++)
            {
                double a = motes[i].X * Math.PI * 2 + t * 0.55;
                double radius = 185 + motes[i].Y * 55 + 9 * Math.Sin(t * 1.6 + motes[i].X * 9);
                float px = (float)(cx + Math.Cos(a) * radius * 1.42);
                float py = (float)(150 + Math.Sin(a) * radius * 0.32);
                int alpha = 45 + (int)(90 * (0.5 + 0.5 * Math.Sin(t * 2 + i)));
                using (SolidBrush dot = new SolidBrush(Color.FromArgb(alpha, 198, 244, 50)))
                    g.FillEllipse(dot, px - 1.6f, py - 1.6f, 3.2f, 3.2f);
            }

            if (logo != null)
            {
                // Same treatment as Settings > Check for update: a solid white plate, a soft
                // dark drop shadow and a faint lime halo. Fixed size and position: no shimmer.
                float scale = 0.82f;
                int lw = Math.Max(1, (int)(logo.Width * scale));
                int lh = Math.Max(1, (int)(logo.Height * scale));
                Rectangle lr = new Rectangle(cx - lw / 2, 92, lw, lh);

                using (GraphicsPath shadowOuter = RoundRect(new Rectangle(lr.X + 5, lr.Y + 9, lr.Width + 10, lr.Height + 10), 34))
                using (SolidBrush shade = new SolidBrush(Color.FromArgb(42, 0, 0, 0)))
                    g.FillPath(shade, shadowOuter);
                using (GraphicsPath shadowInner = RoundRect(new Rectangle(lr.X + 2, lr.Y + 5, lr.Width + 4, lr.Height + 4), 31))
                using (SolidBrush shade = new SolidBrush(Color.FromArgb(70, 0, 0, 0)))
                    g.FillPath(shade, shadowInner);

                for (int i = 6; i >= 1; i--)
                {
                    Rectangle haloRect = Rectangle.Inflate(lr, i * 2, i * 2);
                    using (GraphicsPath haloPath = RoundRect(haloRect, 28 + i * 2))
                    using (Pen halo = new Pen(Color.FromArgb(8 * i, 198, 244, 50), 2f))
                        g.DrawPath(halo, haloPath);
                }

                DrawLogo(g, lr, 1f);
            }

            using (Font top = new Font("Segoe UI", 10f, FontStyle.Regular))
                DrawCentered(g, "Setting up your clipping studio", new Rectangle(0, 46, Width, 24), top,
                             new SolidBrush(Color.FromArgb(169, 154, 145)));

            Color statusColor = failed ? Color.FromArgb(255, 176, 176) : Color.FromArgb(244, 238, 234);
            using (Font statusFont = new Font("Segoe UI", 13f, FontStyle.Bold))
                DrawCentered(g, status, new Rectangle(40, 316, Width - 80, 30), statusFont, new SolidBrush(statusColor));

            using (Font detailFont = new Font("Segoe UI", 9.5f, FontStyle.Regular))
                DrawCentered(g, detail, new Rectangle(40, 348, Width - 80, 24), detailFont,
                             new SolidBrush(Color.FromArgb(150, 137, 128)));

            int bx = 86, by = 404, bw = Width - 172, bh = 10;
            using (GraphicsPath bar = RoundRect(new Rectangle(bx, by, bw, bh), 5))
            {
                g.SetClip(bar);
                using (SolidBrush track = new SolidBrush(Color.FromArgb(46, 36, 30)))
                    g.FillRectangle(track, bx, by, bw, bh);

                int visual = Math.Max(0, Math.Min(100, progress + (done || failed ? 0 : (int)(1.4 * Math.Sin(t * 3)))));
                int fill = (int)(bw * visual / 100.0);
                if (fill > 0)
                {
                    using (LinearGradientBrush line = new LinearGradientBrush(
                        new Rectangle(bx, by, fill, bh),
                        Color.FromArgb(140, 198, 244, 50), Color.FromArgb(198, 244, 50), LinearGradientMode.Horizontal))
                        g.FillRectangle(line, bx, by, fill, bh);

                    int shimmerX = bx + ((frame * 7) % (bw + 120)) - 90;
                    using (LinearGradientBrush shimmer = new LinearGradientBrush(
                        new Rectangle(shimmerX, by, 80, bh),
                        Color.FromArgb(0, 255, 255, 255), Color.FromArgb(95, 255, 255, 255),
                        LinearGradientMode.Horizontal))
                        g.FillRectangle(shimmer, shimmerX, by, 80, bh);
                }
                g.ResetClip();
                using (Pen edge = new Pen(Color.FromArgb(80, 255, 255, 255), 1f))
                    g.DrawPath(edge, bar);
            }

            using (Font pctFont = new Font("Segoe UI", 9f, FontStyle.Bold))
            {
                StringFormat right = new StringFormat();
                right.Alignment = StringAlignment.Far;
                g.DrawString(progress + "%", pctFont, new SolidBrush(Color.FromArgb(198, 244, 50)),
                             new RectangleF(bx, by - 24, bw, 18), right);
                right.Dispose();
            }

            using (Font foot = new Font("Segoe UI", 8.5f, FontStyle.Regular))
                DrawCentered(g, "Built by Soham Chatterjee", new Rectangle(0, 462, Width, 22), foot,
                             new SolidBrush(Color.FromArgb(130, 117, 108)));

            if (failed)
            {
                using (SolidBrush alert = new SolidBrush(Color.FromArgb(220, 255, 92, 92)))
                    g.FillRectangle(alert, 0, 0, Width, 4);
            }
        }

        private void DrawLogo(Graphics g, Rectangle rect, float alpha)
        {
            if (logo == null || alpha <= 0f) return;
            using (ImageAttributes ia = new ImageAttributes())
            {
                ColorMatrix matrix = new ColorMatrix();
                matrix.Matrix33 = Math.Max(0f, Math.Min(1f, alpha));
                ia.SetColorMatrix(matrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap);
                g.DrawImage(logo, rect, 0, 0, logo.Width, logo.Height, GraphicsUnit.Pixel, ia);
            }
        }

        private static void DrawCentered(Graphics g, string text, Rectangle rect, Font font, Brush brush)
        {
            if (String.IsNullOrEmpty(text)) return;
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;
            g.DrawString(text, font, brush, rect, format);
            format.Dispose();
        }

        private static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            int d = Math.Min(radius * 2, Math.Min(r.Width, r.Height));
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void OnClick(EventArgs e)
        {
            if (failed || done) Close();
            base.OnClick(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) Close();
            base.OnKeyDown(e);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (child != null && !child.HasExited)
            {
                try { child.Kill(); } catch { }
            }
            if (!String.IsNullOrEmpty(tempDir))
            {
                try { Directory.Delete(tempDir, true); } catch { }
            }
            base.OnFormClosing(e);
        }
    }

    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            try { SetProcessDPIAware(); } catch { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool preview = args.Length > 0 && String.Equals(args[0], "--preview", StringComparison.OrdinalIgnoreCase);
            Application.Run(new Splash(preview));
        }

        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();
    }
}
