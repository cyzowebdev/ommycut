param(
    [string]$RepoUrl = "https://github.com/cyzowebdev/ommycut.git",
    [string]$Branch = "main",
    [switch]$NoPrompt
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$InstallDir = "C:\ommycut"
$LegacyDir = Join-Path $env:LOCALAPPDATA "Programs\ClipKontrast"
$TempRoot = Join-Path $env:TEMP ("ommycut-install-" + [guid]::NewGuid().ToString("N"))
$Log = Join-Path $env:TEMP "ommycut-install.log"

function Log($msg) {
    $line = "[{0}] {1}" -f (Get-Date).ToString("s"), $msg
    Write-Host $line
    Add-Content -Path $Log -Value $line -ErrorAction SilentlyContinue
}

function Fail($msg) {
    Log "ERROR: $msg"
    if (-not $NoPrompt) {
        Write-Host ""
        Write-Host "OmmyCut install failed. Details: $Log" -ForegroundColor Red
        Write-Host "Press Enter to close."
        Read-Host | Out-Null
    }
    exit 1
}

function Migrate-LegacyData {
    if (-not (Test-Path $LegacyDir) -or ($LegacyDir -ieq $InstallDir)) { return }
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    foreach ($name in @("data", "storage.json", ".env")) {
        $from = Join-Path $LegacyDir $name
        $to = Join-Path $InstallDir $name
        if ((Test-Path -LiteralPath $from) -and -not (Test-Path -LiteralPath $to)) {
            Log "Bringing your $name over from the previous install."
            Copy-Item -LiteralPath $from -Destination $to -Recurse -Force
        }
    }
    foreach ($file in @((Join-Path $InstallDir "storage.json"), (Join-Path $InstallDir ".env"))) {
        if (-not (Test-Path -LiteralPath $file)) { continue }
        try {
            $text = Get-Content -LiteralPath $file -Raw
            $updated = $text -replace [regex]::Escape($LegacyDir), ($InstallDir -replace '\$', '$$$$')
            if ($updated -ne $text) { Set-Content -LiteralPath $file -Value $updated -Encoding UTF8 }
        } catch { Log "Could not update saved paths in $file`: $($_.Exception.Message)" }
    }
}

function Remove-LegacyShortcuts {
    $paths = @(
        (Join-Path $env:USERPROFILE "Desktop\ClipKontrast.lnk"),
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\ClipKontrast.lnk"),
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\ClipKontrast")
    )
    if ($env:PUBLIC) { $paths += (Join-Path $env:PUBLIC "Desktop\ClipKontrast.lnk") }
    foreach ($p in $paths) {
        if ($p -and (Test-Path -LiteralPath $p)) {
            try { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop }
            catch { Log "Could not remove the old shortcut: $p" }
        }
    }
    Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ClipKontrast" -Recurse -Force -ErrorAction SilentlyContinue
}

function Retire-LegacyInstall {
    if (-not (Test-Path $LegacyDir) -or ($LegacyDir -ieq $InstallDir)) { return }
    if (-not (Test-Path (Join-Path $InstallDir "app\studio\server.py"))) { return }
    try {
        $busy = @(Get-CimInstance Win32_Process -ErrorAction Stop |
                  Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($LegacyDir, [StringComparison]::OrdinalIgnoreCase) })
    } catch { $busy = @() }
    if ($busy.Count -gt 0) {
        Log "The previous install is still running; it will be removed after a restart."
        return
    }
    try {
        Remove-Item -LiteralPath $LegacyDir -Recurse -Force -ErrorAction Stop
        Log "Removed the previous install folder."
    } catch { Log "Could not remove the previous install folder: $($_.Exception.Message)" }
}

function Get-WebFile($url, $path) {
    Log "Downloading $url"
    Invoke-WebRequest -Uri $url -OutFile $path -UseBasicParsing -TimeoutSec 900
}

function Test-ZipFile($path) {
    if (-not (Test-Path -LiteralPath $path)) { return $false }
    if ((Get-Item -LiteralPath $path).Length -lt 100) { return $false }
    $fs = [IO.File]::OpenRead($path)
    try {
        $head = New-Object byte[] 4
        $read = $fs.Read($head, 0, 4)
        return ($read -eq 4 -and $head[0] -eq 0x50 -and $head[1] -eq 0x4B)
    } catch { return $false } finally { $fs.Dispose() }
}

function Get-ReleaseZip {
    $zip = Join-Path $TempRoot "ommycut-source.zip"
    $clean = $RepoUrl -replace '/$', '' -replace '\.git$', ''
    $urls = @(
        "https://github.com/cyzowebdev/ommycut/archive/refs/heads/$Branch.zip",
        "https://github.com/cyzowebdev/ommycut/archive/refs/heads/master.zip",
        "$clean/archive/refs/heads/$Branch.zip",
        "$clean/archive/refs/heads/master.zip"
    )
    foreach ($u in ($urls | Select-Object -Unique)) {
        try {
            Get-WebFile $u $zip
            if (Test-ZipFile $zip) { return $zip }
            Log "GitHub returned a page instead of a zip file for $u"
        } catch { Log "Could not use $u" }
    }
    Fail "OmmyCut is not published on GitHub yet. Upload the repo to https://github.com/cyzowebdev/ommycut, then run this installer again."
}

function Expand-Source($zip) {
    $out = Join-Path $TempRoot "source"
    if (-not (Test-ZipFile $zip)) {
        Fail "The download was not a valid OmmyCut zip. If the repo has not been uploaded yet, publish it first and run the installer again."
    }
    try { Expand-Archive -Path $zip -DestinationPath $out -Force }
    catch { Fail "The download was not a valid OmmyCut zip. If the repo has not been uploaded yet, publish it first and run the installer again." }
    $root = Get-ChildItem $out -Directory | Where-Object { $_.Name -like 'ommycut-*' } | Select-Object -First 1
    if (-not $root) { $root = Get-Item $out }

    # The repo may have been uploaded as the source ZIP itself instead of its extracted
    # contents. Detect that and unpack it so installation still works.
    $inner = Get-ChildItem -LiteralPath $root.FullName -File -Filter 'OmmyCut-GitHub*.zip' -ErrorAction SilentlyContinue |
             Select-Object -First 1
    if ($inner) {
        Log "Found $($inner.Name) in the repo; unpacking it automatically."
        $innerOut = Join-Path $TempRoot "source-inner"
        try { Expand-Archive -Path $inner.FullName -DestinationPath $innerOut -Force }
        catch { Fail "The OmmyCut source zip in the repo could not be opened." }
        $sourceRoot = $innerOut
        if (-not (Test-Path (Join-Path $sourceRoot "app\requirements.txt")) -and
            -not (Test-Path (Join-Path $sourceRoot "requirements.txt"))) {
            $candidate = Get-ChildItem $innerOut -Directory -ErrorAction SilentlyContinue |
                Where-Object {
                    (Test-Path (Join-Path $_.FullName "app\requirements.txt")) -or
                    (Test-Path (Join-Path $_.FullName "requirements.txt"))
                } | Select-Object -First 1
            if ($candidate) { $sourceRoot = $candidate.FullName }
        }
        return $sourceRoot
    }
    return $root.FullName
}

function Install-Source($src) {
    Log "Installing OmmyCut files to $InstallDir"
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
    # Keep the user's data folder, settings, clips and local overrides.
    $copy = @("app", "web", "python", "ffmpeg", "update")
    foreach ($name in $copy) {
        $from = Join-Path $src $name
        if (Test-Path $from) {
            Copy-Item -Path $from -Destination (Join-Path $InstallDir $name) -Recurse -Force
        }
    }
    foreach ($file in (Get-ChildItem $src -File)) {
        if ($file.Name -eq ".env") { continue }
        Copy-Item -Path $file.FullName -Destination (Join-Path $InstallDir $file.Name) -Force
    }
    # Accept either layout: app\requirements.txt (normal) or a root requirements.txt.
    $appReq = Join-Path $InstallDir "app\requirements.txt"
    if (-not (Test-Path $appReq)) {
        $rootReq = Join-Path $InstallDir "requirements.txt"
        $srcReq = Join-Path $src "requirements.txt"
        $foundReq = $null
        if (Test-Path $rootReq) { $foundReq = $rootReq }
        elseif (Test-Path $srcReq) { $foundReq = $srcReq }
        if ($foundReq) {
            New-Item -ItemType Directory -Path (Join-Path $InstallDir "app") -Force | Out-Null
            Copy-Item -Path $foundReq -Destination $appReq -Force
            Log "Copied requirements.txt into the app folder."
        }
    }
    $example = Join-Path $InstallDir ".env.example"
    $envFile = Join-Path $InstallDir ".env"
    if ((Test-Path $example) -and -not (Test-Path $envFile)) { Copy-Item $example $envFile -Force }
    New-Item -ItemType Directory -Path (Join-Path $InstallDir "data\logs") -Force | Out-Null
}

function Install-Python {
    $py = Join-Path $InstallDir "python\python.exe"
    if (Test-Path $py) { Log "Python runtime already present."; return }
    Log "Downloading Python 3.12.10 (embedded runtime)."
    $pydir = Join-Path $InstallDir "python"
    New-Item -ItemType Directory -Path $pydir -Force | Out-Null
    $pyzip = Join-Path $TempRoot "python.zip"
    Get-WebFile "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip" $pyzip
    Expand-Archive -Path $pyzip -DestinationPath $pydir -Force
    $pth = Join-Path $pydir "python312._pth"
    @("python312.zip", ".", "Lib\site-packages", "..\app", "import site") | Set-Content -Path $pth -Encoding ASCII
    Copy-Item (Join-Path $pydir "pythonw.exe") (Join-Path $pydir "OmmyCut.exe") -Force
    $getpip = Join-Path $TempRoot "get-pip.py"
    Get-WebFile "https://bootstrap.pypa.io/get-pip.py" $getpip
    Log "Installing pip."
    & $py $getpip --disable-pip-version-check --no-warn-script-location | ForEach-Object { Log $_ }
    if ($LASTEXITCODE -ne 0) { Fail "pip installation failed." }
}

function Install-Requirements {
    $py = Join-Path $InstallDir "python\python.exe"
    $req = @(
        (Join-Path $InstallDir "app\requirements.txt"),
        (Join-Path $InstallDir "requirements.txt")
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $req) {
        Fail "requirements.txt is missing from the downloaded source. Upload app\\requirements.txt or requirements.txt to the GitHub repo."
    }
    # pywebview's Windows build needs proxy_tools; build isolation cannot see the
    # embedded interpreter's setuptools, so install these first, without isolation.
    Log " Installing build tools for the native OmmyCut window."
    & $py -m pip install --disable-pip-version-check --no-warn-script-location --upgrade "setuptools==80.9.0" | ForEach-Object { Log $_ }
    if ($LASTEXITCODE -ne 0) { Fail "Installing setuptools failed." }
    & $py -m pip install --disable-pip-version-check --no-warn-script-location --no-build-isolation "proxy_tools==0.1.0" | ForEach-Object { Log $_ }
    if ($LASTEXITCODE -ne 0) { Fail "Installing proxy_tools failed." }
    Log " Installing Python packages (this can take several minutes)."
    & $py -m pip install --disable-pip-version-check --no-warn-script-location -r $req | ForEach-Object { Log $_ }
    if ($LASTEXITCODE -ne 0) { Fail "Installing Python packages failed." }
}

function Install-Ffmpeg {
    $ff = Join-Path $InstallDir "ffmpeg\bin\ffmpeg.exe"
    if (Test-Path $ff) { Log "ffmpeg already present."; return }
    Log "Installing ffmpeg."
    try {
        winget install --id Gyan.FFmpeg -e --accept-source-agreements --accept-package-agreements --silent | Out-Null
        $cmd = Get-Command ffmpeg -ErrorAction SilentlyContinue
        if ($cmd) {
            $ffdir = Join-Path $InstallDir "ffmpeg\bin"
            New-Item -ItemType Directory -Path $ffdir -Force | Out-Null
            Copy-Item $cmd.Source (Join-Path $ffdir "ffmpeg.exe") -Force
            return
        }
    } catch { Log "winget was not available; downloading a portable ffmpeg." }
    $zip = Join-Path $TempRoot "ffmpeg.zip"
    Get-WebFile "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" $zip
    $out = Join-Path $TempRoot "ffmpeg"
    Expand-Archive -Path $zip -DestinationPath $out -Force
    $exe = Get-ChildItem $out -Recurse -Filter ffmpeg.exe | Select-Object -First 1
    if (-not $exe) { Fail "The ffmpeg download did not contain ffmpeg.exe." }
    $ffdir = Join-Path $InstallDir "ffmpeg\bin"
    New-Item -ItemType Directory -Path $ffdir -Force | Out-Null
    Copy-Item $exe.FullName (Join-Path $ffdir "ffmpeg.exe") -Force
    $ffprobe = Get-ChildItem $out -Recurse -Filter ffprobe.exe | Select-Object -First 1
    if ($ffprobe) { Copy-Item $ffprobe.FullName (Join-Path $ffdir "ffprobe.exe") -Force }
}

function Make-Shortcuts {
    Log "Creating OmmyCut shortcuts."
    $exe = Join-Path $InstallDir "python\OmmyCut.exe"
    if (-not (Test-Path $exe)) { Copy-Item (Join-Path $InstallDir "python\pythonw.exe") $exe -Force }
    $icon = Join-Path $InstallDir "ommycut.ico"
    $start = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\OmmyCut"
    New-Item -ItemType Directory -Path $start -Force | Out-Null
    $wsh = New-Object -ComObject WScript.Shell
    $targets = @(
        (Join-Path $env:USERPROFILE "Desktop\OmmyCut.lnk"),
        (Join-Path $start "OmmyCut.lnk"),
        (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\OmmyCut.lnk")
    )
    foreach ($lnk in $targets) {
        $s = $wsh.CreateShortcut($lnk)
        $s.TargetPath = $exe
        $s.Arguments = "-m studio.desktop"
        $s.WorkingDirectory = $InstallDir
        $s.IconLocation = "$icon,0"
        $s.Description = "OmmyCut"
        $s.Save()
    }
    New-Item -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmmyCut" -Force | Out-Null
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmmyCut" -Name DisplayName -Value "OmmyCut"
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmmyCut" -Name DisplayIcon -Value $icon
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmmyCut" -Name InstallLocation -Value $InstallDir
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmmyCut" -Name Publisher -Value "Soham Chatterjee"
    Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmmyCut" -Name DisplayVersion -Value "1.0.0"
    Remove-LegacyShortcuts
}

try {
    New-Item -ItemType Directory -Path $TempRoot -Force | Out-Null
    Log "OmmyCut installer started. Repo: $RepoUrl"
    Migrate-LegacyData
    $zip = Get-ReleaseZip
    $src = Expand-Source $zip
    Install-Source $src
    Install-Python
    Install-Requirements
    Install-Ffmpeg
    Make-Shortcuts
    Log "Starting OmmyCut."
    Start-Process -FilePath (Join-Path $InstallDir "python\OmmyCut.exe") -ArgumentList "-m studio.desktop" -WorkingDirectory $InstallDir
    Start-Sleep -Seconds 2
    Retire-LegacyInstall
    Log "Done. OmmyCut was installed to $InstallDir"
    Write-Host ""
    Write-Host "OmmyCut installed successfully." -ForegroundColor Green
    Write-Host "It is on your Desktop and in the Start menu." -ForegroundColor Green
} catch {
    Fail $_.Exception.Message
}
