"""On-demand OmmyCut updates from the owner's GitHub repository.

Nothing looks in the background. When the owner presses "Check for update" in Settings, this looks for a numbered
OmmyCut zip in GitHub Releases, in the repository tree, or in a latest.json manifest, picks the highest version, and
(if it is newer than this copy) downloads and stages it as app.new. The launcher swaps app.new into place and starts
OmmyCut again; data, settings, the private Python runtime and ffmpeg are untouched.

The zip must contain an `app/` folder with studio/server.py. Name it with a version, for example
`OmmyCut-GitHub-2026.11.23.1.zip`, or put that version in the GitHub release tag.
"""
from __future__ import annotations

import json
import re
import shutil
import threading
import time
import zipfile
from pathlib import Path
from urllib.parse import quote

from . import config

REPO = ((config.env("OMMYCUT_UPDATE_REPO") or config.env("CLIPKONTRAST_UPDATE_REPO") or
         "cyzowebdev/ommycut").strip().strip("/"))
BRANCH = (config.env("OMMYCUT_UPDATE_BRANCH") or "main").strip() or "main"
API = f"https://api.github.com/repos/{REPO}"
RAW = f"https://raw.githubusercontent.com/{REPO}/{quote(BRANCH, safe='')}/"
UA = {"User-Agent": "OmmyCut-update", "Accept": "application/vnd.github+json"}

_state = {"checked": 0.0, "result": None, "reached": False, "online": False, "error": "", "asset": None}
_job = {"phase": "idle", "progress": 0.0, "error": "", "version": "", "message": ""}
_saw_response = False
_lock = threading.Lock()
_click_lock = threading.Lock()
_last_click = 0.0
CLICK_GAP = 10
CHECK_GAP = 30


def _version(v: str) -> tuple:
    parts = re.findall(r"\d+", str(v or ""))
    return tuple(int(p) for p in parts[:6]) if parts else (0,)


def _vtext(text: str) -> str:
    """The first dotted version-looking number in a name or tag."""
    m = re.search(r"(?<!\d)v?(\d+(?:\.\d+){1,4})(?!\d)", str(text or ""))
    return m.group(1) if m else ""


def _notes(body: str) -> list:
    out = []
    for line in str(body or "").splitlines():
        line = line.strip().lstrip("-*• ")
        if line and not line.startswith("#") and not line.startswith("!["):
            out.append(line[:160])
        if len(out) >= 12:
            break
    return out


def _get(url: str, timeout: int = 20):
    global _saw_response
    import httpx
    r = httpx.get(url, headers=UA, timeout=timeout, follow_redirects=True)
    _saw_response = True                      # GitHub answered, even if it was a 404 for a repo not created yet
    return r


def _release_candidates() -> list:
    """Numbered zip assets on GitHub Releases, newest releases first."""
    r = _get(f"{API}/releases?per_page=20")
    if r.status_code != 200:
        return []
    out = []
    for rel in r.json() if isinstance(r.json(), list) else []:
        tag = _vtext(rel.get("tag_name") or "")
        notes = _notes(rel.get("body") or "")
        page = str(rel.get("html_url") or "")
        for a in rel.get("assets") or []:
            name = str(a.get("name") or "")
            if not name.lower().endswith(".zip"):
                continue
            version = _vtext(name) or tag
            url = str(a.get("browser_download_url") or "")
            if version and url.startswith("https://"):
                out.append({"version": version, "url": url, "name": name, "notes": notes, "page": page})
    return out


def _tree_candidates() -> list:
    """Numbered zip files committed to the repository itself."""
    r = _get(f"{API}/git/trees/{quote(BRANCH, safe='')}?recursive=1")
    if r.status_code != 200:
        return []
    tree = (r.json() or {}).get("tree") or []
    files = [str(i.get("path") or "") for i in tree if i.get("type") == "blob"
             and str(i.get("path") or "").lower().endswith(".zip")]
    if not files:
        return []

    versions = {p: _vtext(p) for p in files}
    if not any(versions.values()):                  # plain names: use VERSION from the repo if it has one
        fallback = ""
        for vfile in ("VERSION", "app/VERSION"):
            try:
                vr = _get(RAW + vfile, 12)
                if vr.status_code == 200:
                    fallback = _vtext(vr.text)
                    if fallback:
                        break
            except Exception:  # noqa: BLE001
                pass
        if fallback:
            versions = {p: fallback for p in files}

    return [{"version": v, "url": RAW + quote(p, safe="/"), "name": p.split("/")[-1], "notes": [],
             "page": f"https://github.com/{REPO}/tree/{quote(BRANCH, safe='')}"}
            for p, v in versions.items() if v]



def _manifest_candidates() -> list:
    """Old-style latest.json, if the owner publishes one next to the release or in the repo."""
    urls = (f"https://github.com/{REPO}/releases/latest/download/latest.json", RAW + "latest.json")
    for url in urls:
        try:
            r = _get(url, 12)
            if r.status_code != 200:
                continue
            m = json.loads(r.content.decode("utf-8-sig"))
            if not isinstance(m, dict):
                continue
            v = _vtext(m.get("version") or "")
            zip_url = str(m.get("app_zip") or m.get("zip") or "")
            if v and zip_url.startswith("https://"):
                return [{"version": v, "url": zip_url, "name": zip_url.split("/")[-1],
                         "notes": _notes("\n".join(str(n) for n in (m.get("notes") or []))), "page": ""}]
        except Exception:  # noqa: BLE001
            pass
    return []


def check(force: bool = False):
    """Find the newest numbered zip. Returns the dashboard result, or None when this copy is current."""
    global _saw_response
    with _lock:
        now = time.time()
        if not force and now - _state["checked"] < CHECK_GAP:
            return _state["result"]
        _state["checked"] = now
        _saw_response = False
        candidates = []
        errors = []
        for name, fn in (("releases", _release_candidates), ("repository", _tree_candidates),
                         ("manifest", _manifest_candidates)):
            try:
                candidates += fn()
            except Exception as e:  # noqa: BLE001 - try the next source
                errors.append(f"{name}: {str(e)[:80]}")
        _state["online"] = _saw_response
        _state["reached"] = bool(candidates)
        if candidates:
            _state["error"] = ""
        elif _saw_response:
            _state["error"] = "No new update"
        else:
            _state["error"] = "; ".join(errors[:2]) if errors else "Could not reach GitHub."
        if not candidates:
            _state.update(result=None, asset=None)
            return None

        # Prefer the highest version; a release asset wins a tie over a raw repository file.
        best = max(candidates, key=lambda c: (_version(c["version"]),
                                              0 if "raw.githubusercontent.com" in c["url"] else 1))
        latest = best["version"]
        if _version(latest) <= _version(config.APP_VERSION):
            _state.update(result=None, asset=None)
            return None

        _state["asset"] = best
        _state["result"] = {"current": config.APP_VERSION or "0", "latest": latest, "behind": None,
                            "notes": best["notes"], "url": best["page"], "zip": best["name"],
                            "restart": False, "installed": True, "source": "github"}
        return _state["result"]


def check_now() -> dict:
    global _last_click
    with _click_lock:
        force = time.time() - _last_click >= CLICK_GAP
        if force:
            _last_click = time.time()
    up = check(force=force)
    return {"update": up, "current": config.APP_VERSION or "0", "reached": bool(_state["reached"]),
            "online": bool(_state["online"]), "error": _state["error"]}


def progress() -> dict:
    return dict(_job)


def _download(url: str, dest: Path):
    import httpx
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with httpx.stream("GET", url, headers=UA, timeout=httpx.Timeout(120, connect=20), follow_redirects=True) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length") or 0)
        got = 0
        with open(tmp, "wb") as f:
            for chunk in r.iter_bytes(1 << 20):
                f.write(chunk)
                got += len(chunk)
                if total:
                    _job["progress"] = min(0.92, 0.18 + 0.74 * got / total)
                else:
                    _job["progress"] = min(0.90, _job["progress"] + 0.01)
    if not zipfile.is_zipfile(tmp):
        tmp.unlink(missing_ok=True)
        raise RuntimeError("The file on GitHub is not a valid OmmyCut zip.")
    tmp.replace(dest)


def _stage(zip_path: Path, version: str):
    """Copy only the zip's app/ folder into app.new, refusing paths that escape it."""
    new = config.INSTALL_DIR / "app.new"
    if new.exists():
        shutil.rmtree(new, ignore_errors=True)
    new.mkdir(parents=True)
    prefix = ""
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = [i.filename.replace("\\", "/") for i in z.infolist()]
            for n in names:
                if n.endswith("app/studio/server.py"):
                    prefix = n[: -len("app/studio/server.py")]
                    break
            if not prefix and ("app/studio/server.py" in names or "studio/server.py" in names):
                prefix = ""
            elif not prefix:
                raise RuntimeError("That zip does not contain OmmyCut's app folder.")
            want = prefix + "app/"
            for info in z.infolist():
                n = info.filename.replace("\\", "/")
                if not n.startswith(want):
                    continue
                rel = n[len(want):]
                if not rel or rel.endswith("/"):
                    continue
                parts = Path(rel).parts
                if any(p in {"__pycache__", ".git", "data", "models", "users", "tmp", "logs"}
                       or p.endswith((".pyc", ".db", ".json")) for p in parts):
                    continue
                target = (new / rel).resolve()
                if target != new.resolve() and new.resolve() not in target.parents:
                    raise RuntimeError("The update file has an unsafe path. Nothing was changed.")
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as src, open(target, "wb") as f:
                    shutil.copyfileobj(src, f)
    except zipfile.BadZipFile:
        shutil.rmtree(new, ignore_errors=True)
        raise RuntimeError("The update zip is damaged. Nothing was changed.") from None
    except Exception:
        shutil.rmtree(new, ignore_errors=True)
        raise

    if not (new / "studio" / "server.py").is_file():
        shutil.rmtree(new, ignore_errors=True)
        raise RuntimeError("The update zip is missing OmmyCut's server. Nothing was changed.")
    (new / "VERSION").write_text(version[:40], encoding="utf-8")


def apply() -> dict:
    """Start the update in the background. The page follows progress()."""
    if not config.INSTALLED:
        raise RuntimeError("Automatic updates work in the installed OmmyCut app.")
    if not _state["asset"]:
        check(force=True)
    asset = _state["asset"]
    if not asset:
        raise RuntimeError(_state["error"] or "No newer numbered zip was found on GitHub.")
    if _job["phase"] in ("downloading", "installing", "restarting"):
        return progress()

    _job.update(phase="downloading", progress=0.18, error="", version=asset["version"],
                message=f"Downloading {asset['name']}")

    def work():
        from . import selfupdate
        try:
            upd = config.INSTALL_DIR / "update"
            upd.mkdir(parents=True, exist_ok=True)
            dest = upd / "ommycut-github-update.zip"
            _download(asset["url"], dest)
            _job.update(phase="installing", progress=0.95, message="Installing the new version")
            _stage(dest, asset["version"])
            dest.unlink(missing_ok=True)
            _job.update(phase="restarting", progress=1.0, message="Restarting OmmyCut")
            selfupdate._quit(selfupdate.RESTART_CODE)
        except Exception as e:  # noqa: BLE001 - shown on the page; the running copy is untouched
            shutil.rmtree(config.INSTALL_DIR / "app.new", ignore_errors=True)
            _job.update(phase="error", progress=0.0, error=str(e)[:300], message="Update could not finish")

    threading.Thread(target=work, daemon=True, name="ommycut-update").start()
    return progress()
